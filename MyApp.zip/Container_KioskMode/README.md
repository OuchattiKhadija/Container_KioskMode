# Container_KioskMode
Creating of an application container in kiosk mode -Android App-
